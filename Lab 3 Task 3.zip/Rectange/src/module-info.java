/**
 * 
 */
/**
 * 
 */
module Rectange {
}