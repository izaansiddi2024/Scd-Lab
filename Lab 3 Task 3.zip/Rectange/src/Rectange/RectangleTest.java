package Rectange;

import java.util.Date;

public class RectangleTest {

    // CommonFunctions interface
    interface CommonFunctions {
        void searchTicket();
        void bookTicket();
        void cancelTicket();
        void makePayment();
        void fillDetails();
    }

    // Customer class
    public static class Customer implements CommonFunctions {
        private String customerId;
        private String name;
        private String address;
        private String phoneNumber;
        private int age;

        public void addDetails(String customerId, String name, String address, String phoneNumber, int age) {
            this.setCustomerId(customerId);
            this.setName(name);
            this.setAddress(address);
            this.setPhoneNumber(phoneNumber);
            this.setAge(age);
        }

        public void modifyDetails(String name, String address, String phoneNumber, int age) {
            this.setName(name);
            this.setAddress(address);
            this.setPhoneNumber(phoneNumber);
            this.setAge(age);
        }

        @Override
        public void searchTicket() {
            System.out.println("Customer searching for a ticket...");
        }

        @Override
        public void bookTicket() {
            System.out.println("Customer booking a ticket...");
        }

        @Override
        public void cancelTicket() {
            System.out.println("Customer canceling a ticket...");
        }

        @Override
        public void makePayment() {
            System.out.println("Customer making a payment...");
        }

        @Override
        public void fillDetails() {
            System.out.println("Customer filling details...");
        }

		public String getCustomerId() {
			return customerId;
		}

		public void setCustomerId(String customerId) {
			this.customerId = customerId;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getAddress() {
			return address;
		}

		public void setAddress(String address) {
			this.address = address;
		}

		public String getPhoneNumber() {
			return phoneNumber;
		}

		public void setPhoneNumber(String phoneNumber) {
			this.phoneNumber = phoneNumber;
		}

		public int getAge() {
			return age;
		}

		public void setAge(int age) {
			this.age = age;
		}
    }

    // Agent class
    public static class Agent implements CommonFunctions {
        private int id;
        private String name;

        public Agent(int id, String name) {
            this.setId(id);
            this.setName(name);
        }

        @Override
        public void searchTicket() {
            System.out.println("Agent searching for a ticket...");
        }

        @Override
        public void bookTicket() {
            System.out.println("Agent booking a ticket...");
        }

        @Override
        public void cancelTicket() {
            System.out.println("Agent canceling a ticket...");
        }

        @Override
        public void makePayment() {
            System.out.println("Agent making a payment...");
        }

        @Override
        public void fillDetails() {
            System.out.println("Agent filling details...");
        }

		public int getId() {
			return id;
		}

		public void setId(int id) {
			this.id = id;
		}

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}
    }

    // Ticket class
    public static class Ticket {
        private String source;
        private String destination;
        private Date dateOfJourney;
        private String time;
        private String busNumber;
        private String seatNumber;

        public Ticket(String source, String destination, Date dateOfJourney, String time, String busNumber, String seatNumber) {
            this.source = source;
            this.destination = destination;
            this.dateOfJourney = dateOfJourney;
            this.time = time;
            this.busNumber = busNumber;
            this.seatNumber = seatNumber;
        }

        public void printTicketDetails() {
            System.out.println("Ticket Details: " + source + " to " + destination + " on " + dateOfJourney);
        }
    }

    // Refund class
    public static class Refund {
        private float amount;
        private String customerId;

        public Refund(float amount, String customerId) {
            this.amount = amount;
            this.customerId = customerId;
        }

        public void refundAmount() {
            System.out.println("Refunding amount: " + amount + " to customer ID: " + customerId);
        }
    }

    // BookingCounter class
    public static class BookingCounter {
        public void manageBookings() {
            System.out.println("Managing bookings at the counter...");
        }
    }

    // Main method for testing
    public static void main(String[] args) {
        Customer customer = new Customer();
        customer.addDetails("C001", "John Doe", "123 Street", "1234567890", 30);
        customer.searchTicket();
        customer.bookTicket();

        Agent agent = new Agent(101, "Agent Smith");
        agent.searchTicket();

        Ticket ticket = new Ticket("City A", "City B", new Date(), "10:00 AM", "Bus123", "Seat45");
        ticket.printTicketDetails();

        Refund refund = new Refund(500.0f, "C001");
        refund.refundAmount();

        BookingCounter counter = new BookingCounter();
        counter.manageBookings();
    }
}
