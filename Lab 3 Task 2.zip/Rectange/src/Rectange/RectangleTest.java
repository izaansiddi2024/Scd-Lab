package Rectange;

public class RectangleTest {

}
