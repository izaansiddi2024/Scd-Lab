package AlphabetThread;

class AlphabetThread extends Thread {
    private boolean running = true; // Flag to control the stop method

    // Override the run method
    public void run() {
        try {
            for (int i = 0; i < 26 && running; i++) {
                // Generate a random character between 'A' and 'Z'
                char randomChar = (char) ('A' + (Math.random() * 26));
                System.out.println(randomChar);

                // Sleep for a random amount of time (200-800 ms) to simulate fluctuation
                Thread.sleep((int) (200 + Math.random() * 600));
            }
        } catch (InterruptedException e) {
            System.out.println("Thread interrupted: " + e.getMessage());
        }
    }

    // Custom stop method to safely stop the thread
    public void stopThread() {
        running = false;
    }

    public static void main(String[] args) {
        AlphabetThread alphabetThread = new AlphabetThread();

        // Start the thread
        alphabetThread.start();

        // Allow the thread to run for a while before stopping it
        try {
            Thread.sleep(5000); // Main thread sleeps for 5 seconds
        } catch (InterruptedException e) {
            System.out.println("Main thread interrupted: " + e.getMessage());
        }

        // Stop the thread
        alphabetThread.stopThread();
        System.out.println("Thread stopped.");
    }
}
