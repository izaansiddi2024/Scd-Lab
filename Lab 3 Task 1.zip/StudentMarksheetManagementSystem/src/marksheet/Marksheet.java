package marksheet;

import java.util.Scanner;

public class Marksheet {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input: Student Information
        System.out.println("Enter Student's Name:");
        String studentName = scanner.nextLine();

        System.out.println("Enter Total Marks:");
        double totalMarks = scanner.nextDouble();

        System.out.println("Enter Obtained Marks:");
        double obtainedMarks = scanner.nextDouble();

        // Validation for Marks
        if (obtainedMarks > totalMarks || totalMarks <= 0 || obtainedMarks < 0) {
            System.out.println("Invalid marks entered. Please check and try again.");
            return;
        }

        // Calculations
        double percentage = (obtainedMarks / totalMarks) * 100;
        char grade = calculateGrade(percentage);
        double gpa = calculateGPA(grade);

        // Output: Marksheet
        System.out.println("\n--- Marksheet ---");
        System.out.printf("Student Name: %s%n", studentName);
        System.out.printf("Total Marks: %.2f%n", totalMarks);
        System.out.printf("Obtained Marks: %.2f%n", obtainedMarks);
        System.out.printf("Percentage: %.2f%%%n", percentage);
        System.out.printf("Grade: %c%n", grade);
        System.out.printf("GPA: %.2f%n", gpa);

        scanner.close();
    }

    // Method to calculate grade based on percentage
    public static char calculateGrade(double percentage) {
        if (percentage >= 90) return 'A';
        if (percentage >= 80) return 'B';
        if (percentage >= 70) return 'C';
        if (percentage >= 60) return 'D';
        return 'F';
    }

    // Method to calculate GPA based on grade
    public static double calculateGPA(char grade) {
        switch (grade) {
            case 'A': return 4.0;
            case 'B': return 3.0;
            case 'C': return 2.0;
            case 'D': return 1.0;
            case 'F': return 0.0;
            default: return 0.0;
        }
    }
}
