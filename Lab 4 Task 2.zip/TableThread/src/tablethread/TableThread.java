package tablethread;

class TableThread extends Thread {
    private String type;

    // Constructor to specify which table to print
    public TableThread(String type) {
        this.type = type;
    }

    public void run() {
        if (type.equals("roll")) {
            printRollNumberTable();
        } else if (type.equals("dob")) {
            printDateOfBirthTable();
        }
    }

    // Print the table of the student roll number
    private void printRollNumberTable() {
        System.out.println("Table of Student Roll Number (2019-SE-092):");
        for (int i = 1; i <= 10; i++) {
            System.out.println("2019-SE-092 x " + i + " = " + "2019-SE-" + (92 * i));
            try {
                Thread.sleep(500); // Adding delay to simulate concurrent behavior
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }

    // Print the table of the date of birth
    private void printDateOfBirthTable() {
        System.out.println("Table of Date of Birth (05-April):");
        for (int i = 1; i <= 10; i++) {
            System.out.println("05-April x " + i + " = " + "05-April-" + (5 * i));
            try {
                Thread.sleep(500); // Adding delay to simulate concurrent behavior
            } catch (InterruptedException e) {
                System.out.println(e);
            }
        }
    }

    public static void main(String[] args) {
        // Create threads for each table
        TableThread rollNumberThread = new TableThread("roll");
        TableThread dateOfBirthThread = new TableThread("dob");

        // Start threads
        rollNumberThread.start();
        dateOfBirthThread.start();
    }
}
